﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Predjela : Form
    {

        public Predjela()
        {
            InitializeComponent();
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        public class MyClass
        {
            public static List<string> predjelaList { get; set; }
            public static List<string> predjelaListCijene { get; set; }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkedListBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Ništa nije odabrano! Molimo pokušajte ponovo.");
                // checkedListBox1.SelectedIndex--;
            }
            else
            {
                MyClass.predjelaList = new List<string>();
                MyClass.predjelaList = checkedListBox1.CheckedItems.Cast<string>().ToList();
                MessageBox.Show("Vaš odabir dodan je u narudžbu, koju možete pogledati klikom na 'Pregled narudžbe' ");
            }
        }


        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string total = "";
            for (int i = 0; i < MyClass.predjelaList.Count; i++)
            {
                total = total + MyClass.predjelaList[i] + "\n";
            }
            MessageBox.Show(total);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
            this.Close();
        }


        private void button2_Click(object sender, EventArgs e)
        {
            if (checkedListBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Ništa nije odabrano! Molimo pokušajte ponovo.");
                // checkedListBox1.SelectedIndex--;
            }
            else
            {
                this.Hide();
                Form1 finish = new Form1();
                finish.ShowDialog();
                this.Close();
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            MyClass.predjelaListCijene = new List<string>();
            MyClass.predjelaListCijene.Add("Šareni slani rolat_______________3 KM");
            MyClass.predjelaListCijene.Add("Krem juha od šampinjona_____3 KM");
            MyClass.predjelaListCijene.Add("Bistra pileća juha______________2 KM");
            MyClass.predjelaListCijene.Add("Ajvar kocke____________________3 KM");
            MyClass.predjelaListCijene.Add("Pohovani sir___________________5 KM");
            MyClass.predjelaListCijene.Add("Teleća čorba___________________5 KM");

            string total = "";
            for (int i = 0; i < MyClass.predjelaListCijene.Count; i++)
            {
                total = total + MyClass.predjelaListCijene[i] + "\n";
            }
            MessageBox.Show(total);

            //MessageBox.Show("Šareni slani rolat_______________3 KM" + "\n" +
            //                "Krem juha od šampinjona_____3 KM" + "\n" +
            //                "Bistra pileća juha______________2 KM" + "\n" +
            //                "Ajvar kocke__________________2.5 KM" + "\n" +
            //                "Pohovani sir___________________5 KM" + "\n" +
            //                "Teleća čorba___________________5 KM");
        }

        private void Predjela_Load(object sender, EventArgs e)
        {

        }
    }
}
