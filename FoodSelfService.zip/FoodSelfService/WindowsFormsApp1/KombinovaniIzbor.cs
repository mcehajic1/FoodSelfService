﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class KombinovaniIzbor : Form
    {
        public KombinovaniIzbor()
        {
            InitializeComponent();
        }

        private void checkedListBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (checkedListBox1.SelectedIndex == -1 && checkedListBox2.SelectedIndex == -1 && checkedListBox3.SelectedIndex == -1 && checkedListBox4.SelectedIndex == -1 && checkedListBox5.SelectedIndex == -1)
            {
                MessageBox.Show("Ništa nije odabrano! Molimo pokušajte ponovo.");
                // checkedListBox1.SelectedIndex--;
            }
            else
            {
                this.Hide();
                finish1 f1 = new finish1();
                f1.ShowDialog();
                this.Close();
            }
                
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkedListBox1.SelectedIndex == -1 && checkedListBox2.SelectedIndex == -1 && checkedListBox3.SelectedIndex == -1 && checkedListBox4.SelectedIndex == -1 && checkedListBox5.SelectedIndex == -1)
            {
                MessageBox.Show("Ništa nije odabrano! Molimo pokušajte ponovo.");
                // checkedListBox1.SelectedIndex--;
            }
            else
                MessageBox.Show("Vaš odabir dodan je u narudžbu, koju možete pogledati klikom na 'Pregled narudžbe' ");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            pocetna f1 = new pocetna();
            f1.ShowDialog();
            this.Close();
        }

        private void checkedListBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkedListBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkedListBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }
    }
}
