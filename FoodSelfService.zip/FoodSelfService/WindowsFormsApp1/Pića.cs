﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Pića : Form
    {
        public Pića()
        {
            InitializeComponent();
        }

        public class MyClass
        {
            //public static List<List<string>> glJelaNarudzbe { get; set; } //2D lista za narudzbe
            public static List<string> PiceList { get; set; }
            public static List<string> PiceListCijene { get; set; }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkedListBox1.SelectedIndex == -1 )
            {
                MessageBox.Show("Ništa nije odabrano! Molimo pokušajte ponovo.");

            }
            else
            {
                MyClass.PiceList = new List<string>();
                MyClass.PiceList = checkedListBox1.CheckedItems.Cast<string>().ToList(); //dodaj oznacene stvari u listu
                MessageBox.Show("Vaš odabir dodan je u narudžbu, koju možete pogledati klikom na 'Pregled narudžbe' ");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (checkedListBox1.SelectedIndex == -1 )
            {
                MessageBox.Show("Ništa nije odabrano! Molimo pokušajte ponovo.");
                // checkedListBox1.SelectedIndex--;
            }
            else
            {

                this.Hide();
                finish1 f1 = new finish1();
                f1.ShowDialog();
                this.Close();
            }
                
        }

        private void button8_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
               "Espresso______________________1 KM" + "\n" +
               "Machiato_____________________2 KM" + "\n" +
               "Capuccino____________________2 KM" + "\n" +
               "Čaj____________________________1 KM" + "\n" +
               "Nesscaffe_____________________2 KM" + "\n" +
               "Ice coffee_____________________3 KM" + "\n" +
               "Prirodni sokovi_______________2 KM" + "\n" +
               "Coca Cola____________________2 KM" + "\n" +
               "Fanta_________________________2 KM" + "\n" +
               "Sprite_________________________2 KM" + "\n" +
               "Cedevita______________________3 KM" + "\n" +
               "Gusti sokovi___________________3 KM"
               );
        }


        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            pocetna f1 = new pocetna();
            f1.ShowDialog();
            this.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            //ispisivanje narudzbe
            string total = "";
            if (MyClass.PiceList.Count != 0)
            {
                for (int i = 0; i < MyClass.PiceList.Count; i++)
                {
                    total = total + MyClass.PiceList[i] + "\n";
                }
                MessageBox.Show(total);
            }
            else
                MessageBox.Show(" Ništa nije naručeno!");
        }
    }
}
