﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class GlavnaJela : Form
    {
        public GlavnaJela()
        {
            InitializeComponent();
        }

        public class MyClass
        {

            //public static List< List <string> > glJelaNarudzbe { get; set; } //2D lista za narudzbe
            public static List<string> glJelaList { get; set; }
            public static List<string> glJelaListCijene { get; set; }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkedListBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Ništa nije odabrano! Molimo pokušajte ponovo.");
                // checkedListBox1.SelectedIndex--;
            }
            else
            {
                MyClass.glJelaList = new List<string>();
                MyClass.glJelaList = checkedListBox1.CheckedItems.Cast<string>().ToList(); //dodaj oznacene stvari u listu
                MessageBox.Show("Vaš odabir dodan je u narudžbu, koju možete pogledati klikom na 'Pregled narudžbe' ");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (checkedListBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Ništa nije odabrano! Molimo pokušajte ponovo.");
                // checkedListBox1.SelectedIndex--;
            }
            else
            {
                //omoguciti da sadasnja lista postane lista s nazivom "narudzba"

                //MyClass.glJelaNarudzbe = new List<List<string>>();
                //MyClass.glJelaNarudzbe.Add(MyClass.glJelaList);

                //string total = "";
                //if (MyClass.glJelaNarudzbe.Count != 0)
                //{
                //    for (int i = 0; i < MyClass.glJelaNarudzbe.Count; i++)
                //    {
                //        total = total + MyClass.glJelaNarudzbe[i] + "\n";
                //    }
                //    MessageBox.Show(total);
                //}

                this.Hide();
                finish1 f1 = new finish1();
                f1.ShowDialog();
                this.Close();
            }
                
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
            this.Close();
        }

        private void button8_Click(object sender, EventArgs e)
        {

            MyClass.glJelaListCijene = new List<string>();
            MyClass.glJelaListCijene.Add("Lazanje_______________________________8 KM");
            MyClass.glJelaListCijene.Add("Pileća maslanica_____________________6 KM");
            MyClass.glJelaListCijene.Add("Piletina u gorgonzola sosu___________7 KM");
            MyClass.glJelaListCijene.Add("Pileća salata________________________4.5 KM");
            MyClass.glJelaListCijene.Add("Pohovani oslić_______________________7 KM");
            MyClass.glJelaListCijene.Add("Teleće pečenje_______________________9 KM");

            string total = "";
            for (int i = 0; i < MyClass.glJelaListCijene.Count; i++)
            {
                total = total + MyClass.glJelaListCijene[i] + "\n";
            }
            MessageBox.Show(total);

            //MessageBox.Show("Lazanje_______________________________8 KM" + "\n" +
            //    "Pileća maslanica_____________________6 KM" + "\n" +
            //    "Piletina u gorgonzola sosu___________7 KM" + "\n" +
            //    "Pileća salata________________________4.5 KM" + "\n" +
            //    "Pohovani oslić_______________________7 KM" + "\n" +
            //    "Teleće pečenje_______________________9 KM");
        }


        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            pocetna f1 = new pocetna();
            f1.ShowDialog();
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //ispisivanje narudzbe
            string total = "";
            if (MyClass.glJelaList.Count != 0)
            {
                for (int i = 0; i < MyClass.glJelaList.Count; i++)
                {
                    total = total + MyClass.glJelaList[i] + "\n";
                }
              MessageBox.Show(total);
            }   
            else 
            MessageBox.Show(" Ništa nije naručeno!");
        }
    }
}
