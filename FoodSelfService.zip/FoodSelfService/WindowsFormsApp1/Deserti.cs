﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Deserti : Form
    {
        public Deserti()
        {
            InitializeComponent();
        }

        public class MyClass
        {

            //public static List<List<string>> glJelaNarudzbe { get; set; } //2D lista za narudzbe
            public static List<string> desertiList { get; set; }
            public static List<string> desertiListCijene { get; set; }
        }

        private void button8_Click(object sender, EventArgs e)
        {

            MyClass.desertiListCijene = new List<string>();
            MyClass.desertiListCijene.Add("Palačinci s eurokremom___________________4 KM");
            MyClass.desertiListCijene.Add("Palačinci sa džemom______________________3 KM");
            MyClass.desertiListCijene.Add("Tufahije___________________________________5 KM");
            MyClass.desertiListCijene.Add("Cheesecake_______________________________3 KM");
            MyClass.desertiListCijene.Add("Saher torta_________________________________3 KM");
            MyClass.desertiListCijene.Add("Saher torta_________________________________3 KM");

            string total = "";
            for (int i = 0; i < MyClass.desertiListCijene.Count; i++)
            {
                total = total + MyClass.desertiListCijene[i] + "\n";
            }
            MessageBox.Show(total);

            //MessageBox.Show("Palačinci s eurokremom___________________4 KM" + "\n" +
            //    "Palačinci sa džemom______________________3 KM" + "\n" +
            //    "Tufahije___________________________________5 KM" + "\n" +
            //    "Cheesecake______________________________3.5 KM" + "\n" +
            //    "Saher torta_________________________________3 KM" + "\n" +
            //    "Šampita____________________________________2 KM");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkedListBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Ništa nije odabrano! Molimo pokušajte ponovo.");
                // checkedListBox1.SelectedIndex--;
            }
            else
            {
                MyClass.desertiList = new List<string>();
                MyClass.desertiList = checkedListBox1.CheckedItems.Cast<string>().ToList(); //dodaj oznacene stvari u listu
                MessageBox.Show("Vaš odabir dodan je u narudžbu, koju možete pogledati klikom na 'Pregled narudžbe' ");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (checkedListBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Ništa nije odabrano! Molimo pokušajte ponovo.");
                // checkedListBox1.SelectedIndex--;
            }
            else
            {
                this.Hide();
                finish1 f1 = new finish1();
                f1.ShowDialog();
                this.Close();
            }
                
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
            this.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            pocetna f1 = new pocetna();
            f1.ShowDialog();
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //ispisivanje narudzbe
            string total = "";
            if (MyClass.desertiList.Count != 0)
            {
                for (int i = 0; i < MyClass.desertiList.Count; i++)
                {
                    total = total + MyClass.desertiList[i] + "\n";
                }
                MessageBox.Show(total);
            }
            else
                MessageBox.Show(" Ništa nije naručeno!");
        }
    }
}
